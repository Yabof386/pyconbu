# Modul termux
$ pkg update && pkg upgrade
$ pkg install php
$ termux-setup-storage

# Menjalankan
$ cd /sdcard/[lokasi file][enter]
Contoh
$ cd /sdcard/Download/grabcc [enter]
$ php bot.php
